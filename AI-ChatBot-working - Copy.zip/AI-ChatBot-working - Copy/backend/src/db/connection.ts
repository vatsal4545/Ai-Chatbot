import { connect, disconnect } from "mongoose";
async function connectToDatabase() {
  try {
    await connect(process.env.MONGODB_URL);
  } catch (error) {
    console.log(error);
    throw new Error("Could not Connect To MongoDB");
  }
}

async function disconnectFromDatabase() {
  try {
    await disconnect();
  } catch (error) {
    console.log(error);
    throw new Error("Could not Disconnect From MongoDB");
  }
}

export { connectToDatabase, disconnectFromDatabase };

// import mongoose, { disconnect } from "mongoose";
// import { connect } from "mongoose";
// async function connectToDataBase() {
//   try {
//     await connect(process.env.MONGODB_URL);
//   } catch (error) {
//     console.log(error);
//     throw new Error("cannot Connect to MongoDb");
//   }
// }
// async function disconnectFromDataBase() {
//   try {
//     await disconnect();
//   } catch (error) {
//     console.log(error);
//     throw new Error("cannot Disconnect to MongoDb");
//   }
// }

// export { connectToDataBase, disconnectFromDataBase };
